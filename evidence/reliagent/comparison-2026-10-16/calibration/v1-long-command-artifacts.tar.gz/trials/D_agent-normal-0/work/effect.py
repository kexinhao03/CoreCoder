import runpy, sys
sys.argv = ['/Users/haokexin/Desktop/AgentDev/CoreCoder/.worktrees/reliagent-p0/corecoder/evals/live_comparison_worker.py', '/Users/haokexin/Desktop/AgentDev/CoreCoder/.worktrees/reliagent-p0/.tmp/live-task2-smoke-v1/D_agent-normal-0', "effect"]
runpy.run_path('/Users/haokexin/Desktop/AgentDev/CoreCoder/.worktrees/reliagent-p0/corecoder/evals/live_comparison_worker.py', run_name="__main__")
