import runpy, sys
sys.argv = ['/Users/haokexin/Desktop/AgentDev/CoreCoder/.worktrees/reliagent-p0/.tmp/factorial-live-5/sources/durable/corecoder/evals/live_comparison_worker.py', '/Users/haokexin/Desktop/AgentDev/CoreCoder/.worktrees/reliagent-p0/.tmp/factorial-live-5/E-after_accepted_result-4', "effect"]
runpy.run_path('/Users/haokexin/Desktop/AgentDev/CoreCoder/.worktrees/reliagent-p0/.tmp/factorial-live-5/sources/durable/corecoder/evals/live_comparison_worker.py', run_name="__main__")
