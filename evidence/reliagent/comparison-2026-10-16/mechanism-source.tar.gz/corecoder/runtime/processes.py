"""Bounded subprocess execution results."""

from __future__ import annotations

import hashlib
import json
import os
import signal
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from corecoder.runtime.policies import FailureKind

_TRUNCATION_MARKER = "\n... output truncated ...\n"
monotonic = time.monotonic


@dataclass(frozen=True)
class ProcessSpec:
    argv: tuple[str, ...]
    cwd: Path
    timeout_seconds: float
    output_limit: int
    termination_grace_seconds: float
    environment: dict[str, str] | None = None
    stdin: bytes | None = None

    def __post_init__(self) -> None:
        if self.stdin is not None and (not isinstance(self.stdin, bytes) or len(self.stdin) > 1_048_576):
            raise ValueError("stdin must be bytes bounded to 1 MiB")
        if not self.argv:
            raise ValueError("argv must not be empty")
        if self.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        if self.output_limit <= 0:
            raise ValueError("output_limit must be positive")
        if self.termination_grace_seconds < 0:
            raise ValueError("termination_grace_seconds must be non-negative")


@dataclass(frozen=True)
class ProcessResult:
    exit_code: int | None
    stdout: str
    stderr: str
    duration_seconds: float
    failure_kind: FailureKind | None
    termination_confirmed: bool
    process_evidence: ProcessEvidence | None = None


@dataclass(frozen=True)
class ProcessEvidence:
    pid: int
    pgid: int | None
    process_token: str
    argv_sha256: str
    started_at: str
    ended_at: str
    termination_confirmed: bool


class ManagedProcessRunner:
    def run(
        self,
        spec: ProcessSpec,
        cancellation_event: threading.Event,
    ) -> ProcessResult:
        started_at = monotonic()
        if cancellation_event.is_set():
            return ProcessResult(
                exit_code=None,
                stdout="",
                stderr="",
                duration_seconds=monotonic() - started_at,
                failure_kind=FailureKind.CANCELLED,
                termination_confirmed=True,
            )

        platform_options: dict[str, object]
        if os.name == "nt":
            platform_options = {
                "creationflags": subprocess.CREATE_NEW_PROCESS_GROUP,
            }
        else:
            platform_options = {"start_new_session": True}

        process_token = uuid.uuid4().hex
        process_started_at = datetime.now(timezone.utc).isoformat()
        argv_sha256 = hashlib.sha256(
            json.dumps(spec.argv, separators=(",", ":")).encode()
        ).hexdigest()
        environment = dict(os.environ if spec.environment is None else spec.environment)
        environment = {k: v for k, v in environment.items() if k.upper() != "RELIAGENT_CHECKPOINT_KEY"}
        environment["RELIAGENT_PROCESS_TOKEN"] = process_token
        try:
            process = subprocess.Popen(
                _popen_args(spec.argv, windows=os.name == "nt"),
                cwd=spec.cwd,
                env=environment,
                stdin=subprocess.PIPE if spec.stdin is not None else subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=False,
                **platform_options,
            )
        except OSError as error:
            return ProcessResult(
                exit_code=None,
                stdout="",
                stderr=_bound_output(str(error), spec.output_limit),
                duration_seconds=monotonic() - started_at,
                failure_kind=FailureKind.SPAWN_ERROR,
                termination_confirmed=True,
            )

        pgid = None
        if os.name == "posix":
            try:
                pgid = os.getpgid(process.pid)
            except OSError:
                pass

        failure_kind = None
        termination_confirmed = True
        pending_input = spec.stdin
        try:
            while True:
                remaining = spec.timeout_seconds - (monotonic() - started_at)
                cancelled = cancellation_event.is_set()
                if cancelled or remaining <= 0:
                    # A completed process wins a race with cancellation or the deadline.
                    if _termination_confirmed(process):
                        try:
                            stdout_bytes, stderr_bytes = process.communicate(timeout=0.05)
                            break
                        except subprocess.TimeoutExpired:
                            pass

                    failure_kind = FailureKind.CANCELLED if cancelled else FailureKind.TIMED_OUT
                    termination_confirmed = _terminate(process, spec.termination_grace_seconds)
                    try:
                        stdout_bytes, stderr_bytes = process.communicate(
                            timeout=max(spec.termination_grace_seconds, 0.1),
                        )
                    except subprocess.TimeoutExpired as error:
                        stdout_bytes = error.output or b""
                        stderr_bytes = error.stderr or b""
                        termination_confirmed = False
                        if os.name == "posix":
                            process.stdout.close()
                            process.stderr.close()
                        # Windows communicate readers own the pipes until EOF; close may block.
                    if not termination_confirmed:
                        failure_kind = FailureKind.TERMINATION_UNKNOWN
                    break

                try:
                    stdout_bytes, stderr_bytes = process.communicate(input=pending_input, timeout=min(0.05, remaining))
                    if _termination_confirmed(process):
                        break
                    # EOF and parent exit do not prove redirected descendants have stopped.
                    time.sleep(min(0.01, remaining))
                except subprocess.TimeoutExpired:
                    # communicate retains cumulative bytes; retrying must not append them.
                    pass
                finally:
                    pending_input = None

        except BaseException:
            # An interrupted caller must not leave its command running.
            _terminate(process, spec.termination_grace_seconds)
            try:
                process.communicate(timeout=max(spec.termination_grace_seconds, 0.1))
            except subprocess.TimeoutExpired:
                if os.name == "posix":
                    process.stdout.close()
                    process.stderr.close()
            raise

        if failure_kind is None and process.returncode != 0:
            failure_kind = FailureKind.NONZERO_EXIT
        process_ended_at = datetime.now(timezone.utc).isoformat()
        return ProcessResult(
            exit_code=process.returncode if termination_confirmed else None,
            stdout=_bound_output(
                _normalize_newlines(stdout_bytes.decode("utf-8", errors="replace")),
                spec.output_limit,
            ),
            stderr=_bound_output(
                _normalize_newlines(stderr_bytes.decode("utf-8", errors="replace")),
                spec.output_limit,
            ),
            duration_seconds=monotonic() - started_at,
            failure_kind=failure_kind,
            termination_confirmed=termination_confirmed,
            process_evidence=ProcessEvidence(
                pid=process.pid,
                pgid=pgid,
                process_token=process_token,
                argv_sha256=argv_sha256,
                started_at=process_started_at,
                ended_at=process_ended_at,
                termination_confirmed=termination_confirmed,
            ),
        )


def _popen_args(argv: tuple[str, ...], *, windows: bool) -> tuple[str, ...] | str:
    if windows and len(argv) == 3 and argv[1].lower() == "/c":
        # cmd parses shell source itself; CRT argv quoting corrupts nested quotes.
        return f'{subprocess.list2cmdline([argv[0]])} /d /s /c "{argv[2]}"'
    return argv


def _termination_confirmed(process: subprocess.Popen) -> bool:
    if process.poll() is None:
        return False
    if os.name == "posix":
        try:
            os.killpg(process.pid, 0)
        except ProcessLookupError:
            return True
        except OSError:
            return False
        return False
    return True


def _wait_for_termination(process: subprocess.Popen, timeout: float) -> bool:
    deadline = monotonic() + timeout
    while True:
        if _termination_confirmed(process):
            return True
        remaining = deadline - monotonic()
        if remaining <= 0:
            return False
        time.sleep(min(0.01, remaining))


def _terminate(process: subprocess.Popen, grace: float) -> bool:
    if _termination_confirmed(process):
        return True
    for force, timeout in ((False, grace), (True, max(grace, 0.1))):
        try:
            if os.name == "posix":
                os.killpg(process.pid, signal.SIGKILL if force else signal.SIGTERM)
            elif force:
                process.kill()
            else:
                process.terminate()
        except OSError:
            # Even ESRCH is not proof: confirm the parent and original group are gone.
            pass
        if _wait_for_termination(process, timeout):
            return True
    return False


def _bound_output(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    if limit <= len(_TRUNCATION_MARKER):
        return _TRUNCATION_MARKER[:limit]

    content_limit = limit - len(_TRUNCATION_MARKER)
    head_length = int(content_limit * 0.6)
    tail_length = content_limit - head_length
    return text[:head_length] + _TRUNCATION_MARKER + text[-tail_length:]


def _normalize_newlines(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")
